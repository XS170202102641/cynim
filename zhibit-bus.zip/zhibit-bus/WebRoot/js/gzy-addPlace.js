
  //定义省/直辖市数组
  var arr_province = ["请选择城市","广州市","深圳市","珠海市"];
  //定义市/区二维数组
  var arr_city = [
                  ["请选择下车地点"],
                  ["广州珠江新城","广州万胜围","广州天河城","广州岗顶","广州龙洞","广州体育西路"],
                  ['深圳南山区','深圳福田区', '深圳罗湖区'],
                  ['珠海北理珠','珠海北师珠','珠海唐家湾镇','珠海拱北']
              ];
 //获取对象
 var province = document.getElementById('province');
 var city = document.getElementById('city');
 var province2 = document.getElementById('province2');
 var city2 = document.getElementById('city2');
 //初始化菜单
 onload = function () {
     //指定省option标记的个数
     province.length = arr_province.length;
     province2.length = arr_province.length;
     //数组数据写入<option>标记中
     for(var i = 0; i < arr_province.length; i++){
         province.options[i].text = province.options[i].value = arr_province[i];
     }
     for(var i = 0; i < arr_province.length; i++){
         province2.options[i].text = province2.options[i].value = arr_province[i];
     }
     //设置省列表默认选项
     var index = 0;
     var index2 = 0;
     province.index = index;
     province2.index = index2;
     //指定城市option标记的个数
     city.length = arr_city[index].length;
     city2.length = arr_city[index2].length;
     //数组数据写入option标记
     for (var j = 0; j < arr_city[index].length; j++) {
         city.options[j].text = city.options[j].value = arr_city[index][j];
     }
     for (var j = 0; j < arr_city[index2].length; j++) {
         city2.options[j].text = city2.options[j].value = arr_city[index2][j];
     }
 }
 function alter(index) {
     //修改省列表的选择项
     province.index = index;
     //指定城市option标记的个数
     city.length = arr_city[index].length;
     //数组中的数据写入option标记
     for (var j = 0; j < arr_city[index].length; j++) {
         city.options[j].text = city.options[j].value = arr_city[index][j];
     }
 }
 function alter2(index2) {
     //修改省列表的选择项
     province2.index = index2;
     //指定城市option标记的个数
     city2.length = arr_city[index2].length;
     //数组中的数据写入option标记
     for (var j = 0; j < arr_city[index2].length; j++) {
         city2.options[j].text = city2.options[j].value = arr_city[index2][j];
     }
 }
 
 