package com.interceptor;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
import java.util.*;

@SuppressWarnings("serial")
public class adminLoginInterceptor extends AbstractInterceptor{

	@Override
	public String intercept(ActionInvocation ai) throws Exception {
		
		Map<String, Object> session = ai.getInvocationContext().getSession();
		String username = (String)session.get("adminlogin");
		if(username!=null){
			return ai.invoke();
		}else{
			ActionContext ac=ai.getInvocationContext();
			ac.put("errorMessage", "您还未登录，请先登录!");
			return "adminlogin";
		}
		
	}

}
