package com.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.orm.hibernate4.HibernateTemplate;

import com.dao.AdministratorDao;
import com.entity.TAdministrator;


public class AdministratorDaoImpl implements AdministratorDao{
	@Resource(name="hibernateTemplate")
	private HibernateTemplate hibernateTemplate;
	
	//管理员登录
	public TAdministrator Login(String aname, String apassword) {
		String hql = "from TAdministrator a where a.aname = ? and a.apassword = ?";
		try{
			List<TAdministrator> admilist= (List<TAdministrator>) hibernateTemplate.find(hql,new String[]{aname,apassword});
			if (admilist.size()>0) {
				TAdministrator admi = (TAdministrator) admilist.get(0);
				return admi;
			}else{
				return null;
			}
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	//管理员注册
	public boolean Register(TAdministrator admi) {
		try{
			hibernateTemplate.save(admi);
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
	// 管理员信息修改
		public boolean update(TAdministrator admi) {
			try {
				hibernateTemplate.update(admi);
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			} 
		}

}
