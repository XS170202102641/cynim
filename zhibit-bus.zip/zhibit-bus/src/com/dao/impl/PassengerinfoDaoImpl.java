package com.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.orm.hibernate4.HibernateTemplate;

import com.dao.PassengerinfoDao;
import com.entity.TPassengerinfo;
import com.entity.TUser;

public  class PassengerinfoDaoImpl implements PassengerinfoDao {

	@Resource(name="hibernateTemplate")
	private HibernateTemplate hibernateTemplate;
	
	//添加订票人信息

		public boolean add(TPassengerinfo passengerinfo) {
			Integer pid = passengerinfo.getPid();
			try {
				passengerinfo.setPid(pid);
				hibernateTemplate.save(passengerinfo);
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			} 
		}

		//根据用户ID查询订票人信息
		public List<TPassengerinfo> queryAll(TUser user) {
			String hql = "from TPassengerinfo where TUser=?";
			try {
				List<TPassengerinfo> tplist = (List<TPassengerinfo>) hibernateTemplate.find(hql,user);
				if (tplist.size() > 0 && tplist != null) {
					return tplist;
				} else {
					return null;
				}
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		
		//删除订票人信息
		public boolean shanchu(Integer pid) {
			try {
				TPassengerinfo tp = (TPassengerinfo) hibernateTemplate.get(TPassengerinfo.class, pid);
				hibernateTemplate.delete(tp);
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			} 
		}
		
		//修改订票人信息
		public boolean update(TPassengerinfo passengerinfo) {
			try {
				hibernateTemplate.update(passengerinfo);
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			} 
		}
		// 根据Pid获取订票人信息
		public TPassengerinfo modify(Integer pid){
			try {
				TPassengerinfo tp = (TPassengerinfo) hibernateTemplate.get(TPassengerinfo.class, pid);
				return tp;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			} 
		}
		
		//根据uid查询订票人
		public List<TPassengerinfo> findByUid(TUser user) {
			String hql="from TPassengerinfo where TUser=?";
			try{
				List<TPassengerinfo> passengerlist = (List<TPassengerinfo>) hibernateTemplate.find(hql, user);
				return passengerlist;
			}catch(Exception e){
				e.printStackTrace();
				return null;
			}
		}

		//根据pid查询订票人
		public TPassengerinfo findByPid(Integer pid) {
			try{
				TPassengerinfo passengerinfo = hibernateTemplate.get(TPassengerinfo.class, pid);
				return passengerinfo;
			}catch(Exception e){
				e.printStackTrace();
				return null;
			}
		}
}
