package com.dao.impl;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.orm.hibernate4.HibernateTemplate;

import com.dao.TicketDao;
import com.entity.TTicket;

public class TicketDaoImpl implements TicketDao {
	@Resource(name = "hibernateTemplate")
	private HibernateTemplate hibernateTemplate;

	// 用户查询车票信息
	public List<TTicket> findTicket(String tdeparture, String tdestination, Timestamp ttime) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String time = sdf.format(ttime);
		Date dtime = Date.valueOf(time);
		String hql = "from TTicket where tdeparture like '%" + tdeparture + "%' and tdestination like '%" + tdestination
				+ "%' and ttime like '%" + dtime + "%'";
		try {
			List<TTicket> ticketlist = (List<TTicket>) hibernateTemplate.find(hql);
			return ticketlist;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// 用户根据车票id查询车票信息
	public TTicket findByID(Integer tid) {
		try {
			String hql = "update TTicket set tsaleCount = tsaleCount-1 where tid = ?";
			hibernateTemplate.bulkUpdate(hql, tid);
			TTicket ticket = hibernateTemplate.get(TTicket.class, tid);
			return ticket;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// 管理员添加车票
	public boolean addTicket(TTicket ticket) {
		Integer tid = ticket.getTid();
		try {
			ticket.setTid(tid);
			hibernateTemplate.save(ticket);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	// 管理员查看车票
	public List<TTicket> checkTicket(String tdeparture, String tdestination) {
		String hql = "from TTicket where tdeparture like '%" + tdeparture + "%' and tdestination like '%" + tdestination
				+ "%' ";
		try {
			List<TTicket> ticketlist = (List<TTicket>) hibernateTemplate.find(hql);
			return ticketlist;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// 管理员根据车票id查询车票信息
	public TTicket adminFindByID(Integer tid) {
		try {
			TTicket ticket = hibernateTemplate.get(TTicket.class, tid);
			return ticket;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// 管理员修改车票信息
	public boolean ticketUpdate(TTicket ticket) {
		try {
			hibernateTemplate.update(ticket);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	// 管理员删除车票
	public boolean deleteTicket(Integer tid) {
		try {
			TTicket ticket = (TTicket) hibernateTemplate.get(TTicket.class, tid);
			hibernateTemplate.delete(ticket);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}
