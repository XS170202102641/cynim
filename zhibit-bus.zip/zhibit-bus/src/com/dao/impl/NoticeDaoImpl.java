package com.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.orm.hibernate4.HibernateTemplate;

import com.dao.NoticeDao;
import com.entity.TNotice;



public class NoticeDaoImpl implements NoticeDao {
	@Resource(name="hibernateTemplate")
	private HibernateTemplate hibernateTemplate;
	
	public List<TNotice> userqueryAll() {
		String hql = "from TNotice";
		try {
			List<TNotice> noticelist = (List<TNotice>) hibernateTemplate.find(hql);
			if (noticelist.size() > 0 && noticelist != null) {
				return noticelist;
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public List<TNotice> queryAll() {
		String hql = "from TNotice";
		try {
			List<TNotice> noticelist = (List<TNotice>) hibernateTemplate.find(hql);
			if (noticelist.size() > 0 && noticelist != null) {
				return noticelist;
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public boolean add(TNotice nti) {
		Integer nid = nti.getNid();
		try {
			nti.setNid(nid);
			hibernateTemplate.save(nti);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} 
	}
	
	public boolean shanchu(Integer nid) {
		try {
			TNotice nti = (TNotice) hibernateTemplate.get(TNotice.class, nid);
			hibernateTemplate.delete(nti);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} 
	}

}
