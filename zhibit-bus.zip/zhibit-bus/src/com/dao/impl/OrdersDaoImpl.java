package com.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.orm.hibernate4.HibernateTemplate;

import com.dao.OrdersDao;
import com.entity.TOrdersInfo;
import com.entity.TUser;

public class OrdersDaoImpl implements OrdersDao {
	@Resource(name = "hibernateTemplate")
	private HibernateTemplate hibernateTemplate;

	// 查询订单信息
	public List<TOrdersInfo> queryOrders(TUser tuser) {
		String hql = "from TOrdersInfo where TUser=?";
		try {
			List<TOrdersInfo> ordersinfo = (List<TOrdersInfo>) hibernateTemplate.find(hql, tuser);
			return ordersinfo;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// 添加订单信息
	public boolean add(TOrdersInfo ordersinfo) {
		Integer oid = ordersinfo.getOid();
		try {
			ordersinfo.setOid(oid);
			hibernateTemplate.save(ordersinfo);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	// 根据oid删除订单信息
	public boolean deleteOrders(Integer oid,Integer tid) {
		try {
			String hql = "update TTicket set tsaleCount = tsaleCount+1 where tid = ?";
			hibernateTemplate.bulkUpdate(hql, tid);
			TOrdersInfo ordersinfo = (TOrdersInfo) hibernateTemplate.get(TOrdersInfo.class, oid);
			hibernateTemplate.delete(ordersinfo);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

}
