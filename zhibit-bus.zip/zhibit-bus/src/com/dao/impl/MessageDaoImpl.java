package com.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.orm.hibernate4.HibernateTemplate;

import com.dao.MessageDao;
import com.entity.TMessage;
import com.entity.TUser;


public class MessageDaoImpl implements MessageDao {
	@Resource(name="hibernateTemplate")
	private HibernateTemplate hibernateTemplate;
	private List<TUser> msgUser=new ArrayList<>();
	public List<TUser> getMsgUser() {
		return msgUser;
	}
	public void setMsgUser(List<TUser> msgUser) {
		this.msgUser = msgUser;
	}
	
	// 用户添加留言

			public boolean addm(TMessage message) {
				Integer mid = message.getMid();
				try {
					message.setMid(mid);
					hibernateTemplate.save(message);
					return true;
				} catch (Exception e) {
					e.printStackTrace();
					return false;
				} 
			}
			
	//管理员查看留言		
			public List<TMessage> queryAll() {
				String hql = "from TMessage order by mid desc";
				try {
					List<TMessage> messagelist = (List<TMessage>) hibernateTemplate.find(hql);
					if (messagelist.size() > 0 && messagelist != null) {
						return messagelist;
					} else {
						return null;
					}
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			}	
}
