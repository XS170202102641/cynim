package com.dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate4.HibernateTemplate;

import com.dao.UserDao;
import com.entity.TUser;

public class UserDaoImpl implements UserDao {
	@Resource(name="hibernateTemplate")
	private HibernateTemplate hibernateTemplate;
	
	//用户登录
	public TUser Login(Integer uid,String username, String password) {
		String hql = "from TUser  where username = ? and password = ?";
		try{
			List<TUser> userlist= (List<TUser>) hibernateTemplate.find(hql,new String[]{username,password});
			if (userlist.size()>0) {
				TUser user = (TUser) userlist.get(0);
				return user;
			}else{
				return null;
			}
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	
	// 用户注册
	public boolean Register(TUser user) {
		try{
			hibernateTemplate.save(user);
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
	// 修改密码
			public boolean update(TUser user) {
				try {
					hibernateTemplate.update(user);
					return true;
				} catch (Exception e) {
					e.printStackTrace();
					return false;
				} 
			}
}
