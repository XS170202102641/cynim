package com.dao;

import java.sql.Timestamp;
import java.util.List;

import com.entity.TTicket;

public interface TicketDao {
	// 用户查询车票的信息
	public List<TTicket> findTicket(String tdeparture, String tdestination, Timestamp ttime);

	// 用户根据车票id查询车票信息
	public TTicket findByID(Integer tid);

	// 管理员添加车票
	public boolean addTicket(TTicket ticket);
	
	//管理员查看车票
	public List<TTicket> checkTicket(String tdeparture, String tdestination);
	
	// 管理员根据车票id查询车票信息
	public TTicket adminFindByID(Integer tid);
	
	//管理员修改车票信息
	public boolean ticketUpdate(TTicket ticket);
	
	// 管理员删除车票
	public boolean deleteTicket(Integer tid);
	
}
