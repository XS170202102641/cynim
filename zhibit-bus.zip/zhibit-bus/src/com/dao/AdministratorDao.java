package com.dao;

import com.entity.TAdministrator;

public interface AdministratorDao {
	//管理员登录
	public TAdministrator Login(String aname,String apassword);
	//管理员注册
	public boolean Register(TAdministrator admi);
	//修改管理员信息
	public boolean update(TAdministrator admi);

}
