package com.dao;

import java.util.List;

import com.entity.TOrdersInfo;
import com.entity.TUser;

public interface OrdersDao {
	// 查询订单信息
	public List<TOrdersInfo> queryOrders(TUser tuser);

	// 添加订单信息
	public boolean add(TOrdersInfo ordersinfo);

	// 根据oid删除订单
	public boolean deleteOrders(Integer oid,Integer tid);
}
