package com.dao;

import java.util.List;

import com.entity.TNotice;


public interface NoticeDao {
	
		// 查询所有通知
		public List<TNotice> userqueryAll();
	
		// 查询所有通知
		public List<TNotice> queryAll();
		
		// 添加通知
		public boolean add(TNotice nti);
		
		// 根据nid删除通知
		public boolean shanchu(Integer nid);

		

}
