package com.dao;

import java.util.List;

import com.entity.TMessage;

public interface MessageDao {
	//用户添加留言
	public boolean addm(TMessage message);
	
	// 管理员查看留言
	public List<TMessage> queryAll();
}
