package com.entity;

/**
 * TAdministrator entity. @author MyEclipse Persistence Tools
 */

@SuppressWarnings("serial")
public class TAdministrator implements java.io.Serializable {

	// Fields

	private Integer aid;
	private String aname;
	private String apassword;

	// Constructors

	/** default constructor */
	public TAdministrator() {
	}

	/** full constructor */
	public TAdministrator(String aname, String apassword) {
		this.aname = aname;
		this.apassword = apassword;
	}

	// Property accessors

	public Integer getAid() {
		return this.aid;
	}

	public void setAid(Integer aid) {
		this.aid = aid;
	}

	public String getAname() {
		return this.aname;
	}

	public void setAname(String aname) {
		this.aname = aname;
	}

	public String getApassword() {
		return this.apassword;
	}

	public void setApassword(String apassword) {
		this.apassword = apassword;
	}

}