package com.entity;

/**
 * TNotice entity. @author MyEclipse Persistence Tools
 */

@SuppressWarnings("serial")
public class TNotice implements java.io.Serializable {

	// Fields

	private Integer nid;
	private String ntitle;
	private String ncontent;
	private String neditor;
	private String ntime;

	// Constructors

	/** default constructor */
	public TNotice() {
	}

	/** full constructor */
	public TNotice(String ntitle, String ncontent, String neditor, String ntime) {
		this.ntitle = ntitle;
		this.ncontent = ncontent;
		this.neditor = neditor;
		this.ntime = ntime;
	}

	// Property accessors

	public Integer getNid() {
		return this.nid;
	}

	public void setNid(Integer nid) {
		this.nid = nid;
	}

	public String getNtitle() {
		return this.ntitle;
	}

	public void setNtitle(String ntitle) {
		this.ntitle = ntitle;
	}

	public String getNcontent() {
		return this.ncontent;
	}

	public void setNcontent(String ncontent) {
		this.ncontent = ncontent;
	}

	public String getNeditor() {
		return this.neditor;
	}

	public void setNeditor(String neditor) {
		this.neditor = neditor;
	}

	public String getNtime() {
		return this.ntime;
	}

	public void setNtime(String ntime) {
		this.ntime = ntime;
	}

}