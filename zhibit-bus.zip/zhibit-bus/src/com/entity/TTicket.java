package com.entity;

import java.sql.Timestamp;

/**
 * TTicket entity. @author MyEclipse Persistence Tools
 */

@SuppressWarnings("serial")
public class TTicket implements java.io.Serializable {

	// Fields

	private Integer tid;
	private String tdeparture;
	private String tdestination;
	private Float tprice;
	private Timestamp ttime;
	private Integer tsaleCount;

	// Constructors

	/** default constructor */
	public TTicket() {
	}

	/** minimal constructor */
	public TTicket(String tdeparture, Float tprice, Timestamp ttime, Integer tsaleCount) {
		this.tdeparture = tdeparture;
		this.tprice = tprice;
		this.ttime = ttime;
		this.tsaleCount = tsaleCount;
	}

	/** full constructor */
	public TTicket(String tdeparture, String tdestination, Float tprice, Timestamp ttime, Integer tsaleCount) {
		this.tdeparture = tdeparture;
		this.tdestination = tdestination;
		this.tprice = tprice;
		this.ttime = ttime;
		this.tsaleCount = tsaleCount;
	}

	// Property accessors

	public Integer getTid() {
		return this.tid;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public String getTdeparture() {
		return this.tdeparture;
	}

	public void setTdeparture(String tdeparture) {
		this.tdeparture = tdeparture;
	}

	public String getTdestination() {
		return this.tdestination;
	}

	public void setTdestination(String tdestination) {
		this.tdestination = tdestination;
	}

	public Float getTprice() {
		return this.tprice;
	}

	public void setTprice(Float tprice2) {
		this.tprice = tprice2;
	}

	public Timestamp getTtime() {
		return this.ttime;
	}

	public void setTtime(Timestamp ttime) {
		this.ttime = ttime;
	}

	public Integer getTsaleCount() {
		return this.tsaleCount;
	}

	public void setTsaleCount(Integer tsaleCount) {
		this.tsaleCount = tsaleCount;
	}

}