package com.entity;

import java.util.HashSet;
import java.util.Set;

/**
 * TUser entity. @author MyEclipse Persistence Tools
 */

@SuppressWarnings("serial")
public class TUser implements java.io.Serializable {

	// Fields

	private Integer uid;
	public String username;
	public String password;
	private Set TPassengerinfos = new HashSet(0);

	// Constructors

	/** default constructor */
	public TUser() {
	}

	/** minimal constructor */
	public TUser(String username, String password) {
		this.username = username;
		this.password = password;
	}

	/** full constructor */
	public TUser(String username, String password, Set TPassengerinfos) {
		this.username = username;
		this.password = password;
		this.TPassengerinfos = TPassengerinfos;
	}

	// Property accessors

	public Integer getUid() {
		return this.uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set getTPassengerinfos() {
		return this.TPassengerinfos;
	}

	public void setTPassengerinfos(Set TPassengerinfos) {
		this.TPassengerinfos = TPassengerinfos;
	}

}