package com.entity;

import java.sql.Timestamp;

/**
 * TOrdersInfo entity. @author MyEclipse Persistence Tools
 */

@SuppressWarnings("serial")
public class TOrdersInfo implements java.io.Serializable {

	// Fields

	private Integer oid;
	private TUser TUser;
	private Integer tid;
	private String tdeparture;
	private String tdestination;
	private Float tprice;
	private Timestamp ttime;
	private String pname;
	private String pcardno;
	private String ptelephone;
	private String otype;

	// Constructors

	/** default constructor */
	public TOrdersInfo() {
	}

	/** minimal constructor */
	public TOrdersInfo(TUser TUser, Integer tid, String tdeparture, Float tprice, Timestamp ttime, String pname,
			String pcardno, String ptelephone, String otype) {
		this.TUser = TUser;
		this.tid = tid;
		this.tdeparture = tdeparture;
		this.tprice = tprice;
		this.ttime = ttime;
		this.pname = pname;
		this.pcardno = pcardno;
		this.ptelephone = ptelephone;
		this.otype = otype;
	}

	/** full constructor */
	public TOrdersInfo(TUser TUser, Integer tid, String tdeparture, String tdestination, Float tprice, Timestamp ttime,
			String pname, String pcardno, String ptelephone, String otype) {
		this.TUser = TUser;
		this.tid = tid;
		this.tdeparture = tdeparture;
		this.tdestination = tdestination;
		this.tprice = tprice;
		this.ttime = ttime;
		this.pname = pname;
		this.pcardno = pcardno;
		this.ptelephone = ptelephone;
		this.otype = otype;
	}

	// Property accessors

	public Integer getOid() {
		return this.oid;
	}

	public void setOid(Integer oid) {
		this.oid = oid;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public Integer getTid() {
		return this.tid;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public String getTdeparture() {
		return this.tdeparture;
	}

	public void setTdeparture(String tdeparture) {
		this.tdeparture = tdeparture;
	}

	public String getTdestination() {
		return this.tdestination;
	}

	public void setTdestination(String tdestination) {
		this.tdestination = tdestination;
	}

	public Float getTprice() {
		return this.tprice;
	}

	public void setTprice(Float float1) {
		this.tprice = float1;
	}

	public Timestamp getTtime() {
		return this.ttime;
	}

	public void setTtime(Timestamp ttime) {
		this.ttime = ttime;
	}

	public String getPname() {
		return this.pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPcardno() {
		return this.pcardno;
	}

	public void setPcardno(String pcardno) {
		this.pcardno = pcardno;
	}

	public String getPtelephone() {
		return this.ptelephone;
	}

	public void setPtelephone(String ptelephone) {
		this.ptelephone = ptelephone;
	}

	public String getOtype() {
		return this.otype;
	}

	public void setOtype(String otype) {
		this.otype = otype;
	}

}