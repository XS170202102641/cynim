package com.entity;

/**
 * TMessage entity. @author MyEclipse Persistence Tools
 */

@SuppressWarnings("serial")
public class TMessage implements java.io.Serializable {

	// Fields

	private Integer mid;
	private String username;
	private String mmessage;
	private String mtime;

	// Constructors

	/** default constructor */
	public TMessage() {
	}

	/** full constructor */
	public TMessage(String username, String mmessage, String mtime) {
		this.username = username;
		this.mmessage = mmessage;
		this.mtime = mtime;
	}

	// Property accessors

	public Integer getMid() {
		return this.mid;
	}

	public void setMid(Integer mid) {
		this.mid = mid;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getMmessage() {
		return this.mmessage;
	}

	public void setMmessage(String mmessage) {
		this.mmessage = mmessage;
	}

	public String getMtime() {
		return this.mtime;
	}

	public void setMtime(String mtime) {
		this.mtime = mtime;
	}

}