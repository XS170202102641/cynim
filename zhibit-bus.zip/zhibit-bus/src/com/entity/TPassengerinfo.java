package com.entity;

import java.util.HashSet;
import java.util.Set;

/**
 * TPassengerinfo entity. @author MyEclipse Persistence Tools
 */

@SuppressWarnings("serial")
public class TPassengerinfo implements java.io.Serializable {

	// Fields

	private Integer pid;
	private TUser TUser;
	private String pname;
	private String pcardno;
	private String ptelephone;
	private Set TOrdersInfos = new HashSet(0);

	// Constructors

	/** default constructor */
	public TPassengerinfo() {
	}

	/** minimal constructor */
	public TPassengerinfo(TUser TUser, String pname, String pcardno, String ptelephone) {
		this.TUser = TUser;
		this.pname = pname;
		this.pcardno = pcardno;
		this.ptelephone = ptelephone;
	}

	/** full constructor */
	public TPassengerinfo(TUser TUser, String pname, String pcardno, String ptelephone, Set TOrdersInfos) {
		this.TUser = TUser;
		this.pname = pname;
		this.pcardno = pcardno;
		this.ptelephone = ptelephone;
		this.TOrdersInfos = TOrdersInfos;
	}

	// Property accessors

	public Integer getPid() {
		return this.pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public TUser getTUser() {
		return this.TUser;
	}

	public void setTUser(TUser TUser) {
		this.TUser = TUser;
	}

	public String getPname() {
		return this.pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPcardno() {
		return this.pcardno;
	}

	public void setPcardno(String pcardno) {
		this.pcardno = pcardno;
	}

	public String getPtelephone() {
		return this.ptelephone;
	}

	public void setPtelephone(String ptelephone) {
		this.ptelephone = ptelephone;
	}

	public Set getTOrdersInfos() {
		return this.TOrdersInfos;
	}

	public void setTOrdersInfos(Set TOrdersInfos) {
		this.TOrdersInfos = TOrdersInfos;
	}

}