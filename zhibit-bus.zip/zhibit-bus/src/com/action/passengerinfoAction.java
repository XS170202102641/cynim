package com.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.entity.TPassengerinfo;
import com.entity.TUser;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.service.PassengerinfoService;


@SuppressWarnings("serial")
public class passengerinfoAction extends ActionSupport implements ModelDriven<TPassengerinfo>{
	@Resource(name = "passengerinfoService")
	private PassengerinfoService passengerinfoService;
	private List<TPassengerinfo> tplist = new ArrayList<TPassengerinfo>();
	TUser tuser;
	Integer uid;
	Integer pid;
	String pname;
	String pcardno;
	String ptelephone;
	
	public passengerinfoAction(){
		
	}
	public TUser getTuser() {
		return tuser;
	}
	public void setTuser(TUser tuser) {
		this.tuser = tuser;
	}
	public TPassengerinfo getModel() {
		return null;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public PassengerinfoService getPassengerinfoService() {
		return passengerinfoService;
	}

	public void setPassengerinfoService(PassengerinfoService passengerinfoService) {
		this.passengerinfoService = passengerinfoService;
	}

	public List<TPassengerinfo> getTplist() {
		return tplist;
	}

	public void setTplist(List<TPassengerinfo> tplist) {
		this.tplist = tplist;
	}
	
	public Integer getPid() {
		return pid;
	}

	public void setPid(Integer pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPcardno() {
		return pcardno;
	}

	public void setPcardno(String pcardno) {
		this.pcardno = pcardno;
	}

	public String getPtelephone() {
		return ptelephone;
	}

	public void setPtelephone(String ptelephone) {
		this.ptelephone = ptelephone;
	}
	
		//添加订票人信息
		public String add() throws Exception{
			try {
				TPassengerinfo tp = new TPassengerinfo();
				Map<String, Object> session1 =  ActionContext.getContext().getSession();// ��ȡsession����
				tuser = (TUser) session1.get("User");
				tp.setTUser(tuser);
				tp.setPname(pname);
				tp.setPcardno(pcardno);
				tp.setPtelephone(ptelephone);
				if (passengerinfoService.add(tp)) {
					return "success";
				} else {
					return "input";
				}
			} catch (Exception e) {
				e.printStackTrace();
				return "input";
			}
		}
		
		//根据用户ID查询订票人信息
		public String queryAll() throws Exception {
			Map<String, Object> session1 = ActionContext.getContext().getSession();
			tuser = (TUser) session1.get("User");
			List<TPassengerinfo> passengers = passengerinfoService.queryAll(tuser);
			if (passengers != null && passengers.size() > 0) {
				setTplist(passengers);
				return "queryAllSuccess";
			} else {
				setTplist(null);
				return "input";
			}

		}
		
		//删除订票人信息
		public String shanchu() throws Exception {
			if (passengerinfoService.shanchu(pid)) {
				return "shanchuSuccess";
			} else {
				return "input";
			}
		}
		
		//修改订票人信息
		public String update() throws Exception {
			TPassengerinfo tp = new TPassengerinfo();
			Map<String, Object> session1 = ActionContext.getContext().getSession();// ��ȡseesion����
			tuser = (TUser) session1.get("User");
			tp.setTUser(tuser);
			tp.setPid(pid);
			tp.setPname(pname);
			tp.setPcardno(pcardno);
			tp.setPtelephone(ptelephone);
			if (passengerinfoService.update(tp)) {
				return "updateSuccess";
			} else {
				return "input";
			}
		}
		
		// 根据Pid获取订票人信息
		public String modify() throws Exception {
			TPassengerinfo tp = new TPassengerinfo();
			tp = passengerinfoService.modify(getPid());
			if (tp != null) {
				Map<String, Object> session = ActionContext.getContext().getSession();
				session.put("modify", tp);
				return "modifySuccess";
			} else {
				return "input";
			}
		}
		
		// 根据uid获取订票人信息
		public String findByUid() throws Exception {
			// 获取user的session对象
			Map<String, Object> session1 = ActionContext.getContext().getSession();
			tuser = (TUser) session1.get("User");
			List<TPassengerinfo> passengerlist = passengerinfoService.findByUid(tuser);
			if (passengerlist != null && passengerlist.size() > 0) {
				setTplist(passengerlist);
				return "findByUid";
			} else {
				return "findByUidError";
			}
		}
		
		//根据pid查询订票人
		public String findByPid() throws Exception{
			TPassengerinfo passengerinfo = new TPassengerinfo();
			passengerinfo = passengerinfoService.findByPid(pid);
			if(passengerinfo!=null){
				Map<String,Object> session = ActionContext.getContext().getSession();
				session.put("tp_findByPid",passengerinfo);
				return "findByPid";
			}else{
				return "findByPidError";
			}
		}
}
