package com.action;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import com.entity.TNotice;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.service.NoticeService;

@SuppressWarnings("serial")
public class noticeAction extends ActionSupport implements ModelDriven<TNotice> {
	@Resource(name = "noticeService")
	private NoticeService noticeService;
	private List<TNotice> ntilist = new ArrayList<>();

	Integer nid;// 通知ID
	String ntitle;// 标题
	String ncontent;// 内容
	String neditor;// 通知发布方
	String ntime;// 发布时间

	public NoticeService getNoticeService() {
		return noticeService;
	}

	public void setNoticeService(NoticeService noticeService) {
		this.noticeService = noticeService;
	}

	public List<TNotice> getNtilist() {
		return ntilist;
	}

	public void setNtilist(List<TNotice> ntilist) {
		this.ntilist = ntilist;
	}

	public Integer getNid() {
		return nid;
	}

	public void setNid(Integer nid) {
		this.nid = nid;
	}

	public String getNtitle() {
		return ntitle;
	}

	public void setNtitle(String ntitle) {
		this.ntitle = ntitle;
	}

	public String getNcontent() {
		return ncontent;
	}

	public void setNcontent(String ncontent) {
		this.ncontent = ncontent;
	}

	public String getNeditor() {
		return neditor;
	}

	public void setNeditor(String neditor) {
		this.neditor = neditor;
	}

	public String getNtime() {
		return ntime;
	}

	public void setNtime(String ntime) {
		this.ntime = ntime;
	}

	public TNotice getModel() {
		return null;
	}

	// 用户查看公告
	public String userqueryAll() throws Exception {
		List<TNotice> notice = noticeService.queryAll();
		if (notice != null && notice.size() > 0) {
			setNtilist(notice);
			return "userqueryAllSuccess";
		} else {
			setNtilist(null);
			return "userqueryAllError";
		}

	}

	// 查询公告
	public String queryAll() throws Exception {
		List<TNotice> notice = noticeService.queryAll();
		if (notice != null && notice.size() > 0) {
			setNtilist(notice);
			return "queryAllSuccess";
		} else {
			setNtilist(null);
			return "queryAllError";
		}

	}

	// 添加公告
	public String addn() {
		try {
			TNotice nti = new TNotice();
			nti.setNcontent(ncontent);
			nti.setNeditor(neditor);
			nti.setNtime(ntime);
			nti.setNtitle(ntitle);
			if (noticeService.add(nti)) {
				return "actionSuccess";
			} else {
				return "input";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "input";
		}
	}

	// 删除公告
	public String shanchu() throws Exception {
		if (noticeService.shanchu(nid)) {
			return "success";
		} else {
			return "error";
		}
	}

}
