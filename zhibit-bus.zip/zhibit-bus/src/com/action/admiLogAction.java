package com.action;

import java.util.Map;

import javax.annotation.Resource;

import com.service.AdministratorService;
import com.entity.TAdministrator;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class admiLogAction extends ActionSupport{
	@Resource(name="administratorService")
	private AdministratorService administratorService;
	private String aname;
	private String apassword;
		
	public AdministratorService getAdministratorService() {
		return administratorService;
	}

	public void setAdministratorService(AdministratorService administratorService) {
		this.administratorService = administratorService;
	}

	public admiLogAction(){
		
	}
	public String getAname() {
		return aname;
	}

	public void setAname(String aname) {
		this.aname = aname;
	}

	public String getApassword() {
		return apassword;
	}

	public void setApassword(String apassword) {
		this.apassword = apassword;
	}

	public String Login() throws Exception {
		boolean validated = false;
		// 将session参数传递给拦截器
		Map<String, Object> session = ActionContext.getContext().getSession();
		TAdministrator admi = administratorService.Login(aname,apassword);
		session.put("adminlogin", admi.getAname());
		Map<String, Object> session1 = ActionContext.getContext().getSession();
		session1.put("login", admi);
		if (admi != null) {
			validated = true;
		}
		if (validated) {
			return "success";
		} else {
			session.put("errorMessage", "账号或密码错误，请重新登录！");
			return "error";
		}
	}
	
	public String adminRegister() throws Exception {
		TAdministrator admi = new TAdministrator();
		admi.setAname(aname);
		admi.setApassword(apassword);
		if(administratorService.Register(admi)){
			return "success";
		}else{
			return "input";
		}
	}
	
	public String exit()throws Exception{
		Map<String, Object> session = ActionContext.getContext().getSession();
		if(session.get("login")!=null){
			session.remove("login");
		}
		return "success";
	}

}
