package com.action;

import java.util.Map;

import javax.annotation.Resource;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import com.service.UserService;
import com.entity.TUser;

@SuppressWarnings("serial")
public class UserAction extends ActionSupport {
	@Resource(name="userService")
	private UserService userService;
	TUser user;
	Integer uid;
	String username;
	String password;
	private String oldpassword;
	private String newpassword;
	
	public UserAction(){
		
	}
	public UserService getUserService() {
		return userService;
	}
	public TUser getUser() {
		return user;
	}
	public void setUser(TUser user) {
		this.user = user;
	}
	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	public Integer getUid() {
		return uid;
	}
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	public String getOldpassword() {
		return oldpassword;
	}

	public void setOldpassword(String oldpassword) {
		this.oldpassword = oldpassword;
	}

	public String getNewpassword() {
		return newpassword;
	}

	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	}
	
	public String Login() throws Exception {
		boolean validated = false;
		// 将session参数传递给拦截器
		Map<String, Object> session = ActionContext.getContext().getSession();
		session.put("userlogin", username);
		TUser user = userService.Login(uid,username,password);
		Map<String, Object> session1 = ActionContext.getContext().getSession();
		session1.put("User", user);
		if (user != null) {
			validated = true;
		}
		if (validated) {
			return "success";
		} else {
			session.put("errorMessage", "用户名或密码错误");
			return "error";
		}
	}

	public String userRegister() throws Exception {
		TUser user = new TUser();
		user.setUsername(username);
		user.setPassword(password);
		if(userService.Register(user)){
			return "success";
		}else{
			return "input";
		}
	}
	
	public String update() throws Exception {
		 user = (TUser)ActionContext.getContext().getSession().get("User");
		if(user.getPassword().equals(oldpassword)){
			user.setPassword(newpassword);
			userService.update(user);
			ActionContext.getContext().getSession().clear();
			return "success";
		}
		else{
			Map<String, Object> session = ActionContext.getContext().getSession();
			session.put("errorpwd", "旧密码输入不正确!");
		}
		return "input";
	   }
	
	public String exit()throws Exception{
		Map<String, Object> session = ActionContext.getContext().getSession();
		if(session.get("User")!=null){
			session.remove("User");
			session.remove("userlogin");
		}
		return "success";
	}
}
