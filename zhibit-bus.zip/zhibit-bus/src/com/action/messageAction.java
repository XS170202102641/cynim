package com.action;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.entity.TMessage;
import com.entity.TUser;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.service.MessageService;

@SuppressWarnings("serial")
public class messageAction extends ActionSupport {
	@Resource(name = "messageService")
	MessageService messageService;
	private List<TMessage> msglist = new ArrayList<>();
	TUser tuser;
	Integer uid;
	String mmessage;
	String mtime;
	String username;

	public messageAction() {

	}

	public List<TMessage> getMsglist() {
		return msglist;
	}

	public void setMsglist(List<TMessage> msglist) {
		this.msglist = msglist;
	}

	public MessageService getMessageService() {
		return messageService;
	}

	public void setMessageService(MessageService messageService) {
		this.messageService = messageService;
	}

	public TUser getTuser() {
		return tuser;
	}

	public void setTuser(TUser tuser) {
		this.tuser = tuser;
	}

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public String getMmessage() {
		return mmessage;
	}

	public void setMmessage(String mmessage) {
		this.mmessage = mmessage;
	}

	public String getMtime() {
		return mtime;
	}

	public void setMtime(String mtime) {
		this.mtime = mtime;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	// 用户添加留言
	public String addm() throws Exception {
		try {
			TMessage tm = new TMessage();
			Map<String, Object> session1 = ActionContext.getContext().getSession();
			tuser = (TUser) session1.get("User");
			Date mtime = new Date(System.currentTimeMillis());
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String time = sdf.format(mtime);
			Map<String, Object> session2 = ActionContext.getContext().getSession();
			session2.put(time, time);
			Map<String, Object> session = ActionContext.getContext().getSession();
			String username = (String) session.get("userlogin");
			tm.setUsername(username);
			tm.setMmessage(mmessage);
			tm.setMtime(time);
			if (messageService.addm(tm)) {
				return "success";
			} else {
				return "input";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "input";
		}
	}

	// 查询留言
	public String queryAll() throws Exception {
		List<TMessage> message = messageService.queryAll();
		if (message != null && message.size() > 0) {
			setMsglist(message);
			return "queryAllSuccess";
		} else {
			setMsglist(null);
			return "queryerror";
		}

	}
}
