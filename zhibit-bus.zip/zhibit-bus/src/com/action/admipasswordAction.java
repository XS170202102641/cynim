package com.action;


import java.util.Map;

import javax.annotation.Resource;


import com.entity.TAdministrator;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.service.AdministratorService;

@SuppressWarnings("serial")
public class admipasswordAction extends ActionSupport{
	@Resource(name="administratorService")
	private AdministratorService administratorService;
	@Resource(name="admin")
	private TAdministrator admi;
	
	private String oldpassword;
	private String newpassword;
	
	public admipasswordAction(){
		
	}

	public AdministratorService getAdministratorService() {
		return administratorService;
	}

	public void setAdministratorService(AdministratorService administratorService) {
		this.administratorService = administratorService;
	}
	
	

	public TAdministrator getAdmi() {
		return admi;
	}

	public void setAdmi(TAdministrator admi) {
		this.admi = admi;
	}

	public String getOldpassword() {
		return oldpassword;
	}

	public void setOldpassword(String oldpassword) {
		this.oldpassword = oldpassword;
	}

	public String getNewpassword() {
		return newpassword;
	}

	public void setNewpassword(String newpassword) {
		this.newpassword = newpassword;
	};
	;
	public String update() throws Exception {
		 admi = (TAdministrator)ActionContext.getContext().getSession().get("login");
		if(admi.getApassword().equals(oldpassword)){
			admi.setApassword(newpassword);
			administratorService.update(admi);
			ActionContext.getContext().getSession().clear();
			return "success";
		}
		else{
			Map<String, Object> session = ActionContext.getContext().getSession();
			session.put("errorpwd", "旧密码输入不正确!");
		}
		return "input";
	   }
}
