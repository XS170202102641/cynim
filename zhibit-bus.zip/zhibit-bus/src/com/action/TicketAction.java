package com.action;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;

import com.entity.TTicket;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.service.TicketService;

@SuppressWarnings("serial")
public class TicketAction extends ActionSupport implements ModelDriven<TTicket> {
	@Resource(name = "ticketService")
	private TicketService ticketService;

	private List<TTicket> ticketlist = new ArrayList<>();
	Integer tid;
	String tdeparture;
	String tdestination;
	Float tprice;
	Timestamp ttime;
	Integer tsaleCount;
	String time;

	// 查询车票信息
	public String findTicket() throws Exception {
		List<TTicket> tickets = ticketService.findTicket(tdeparture, tdestination, ttime);
		if (tickets != null && tickets.size() > 0) {
			setTicketlist(tickets);
			return "findTicket";
		} else {
			setTicketlist(null);
			return "findTicketError";
		}

	}

	// 根据车票id查询车票信息
	public String findByID() throws Exception {
		TTicket ticket = new TTicket();
		ticket = ticketService.findByID(tid);
		if (ticket != null) {
			if (ticket.getTsaleCount() < 0) {
				return "error";
			}
			Map<String, Object> session = ActionContext.getContext().getSession();
			session.put("t_findID", ticket);
			return "findByID";
		} else {
			return "error";
		}
	}

	// 管理员添加车票
	public String addTicket() throws Exception {
		try {
			TTicket ticket = new TTicket();
			ttime = Timestamp.valueOf(time);
			ticket.setTid(tid);
			ticket.setTdeparture(tdeparture);
			ticket.setTdestination(tdestination);
			ticket.setTtime(ttime);
			ticket.setTprice(tprice);
			ticket.setTsaleCount(tsaleCount);
			if (ticketService.addTicket(ticket)) {
				return "addTicket";
			} else {
				return "input";
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "input";
		}
	}

	// 管理员查看车票信息
	public String checkTicket() throws Exception {
		List<TTicket> tickets = ticketService.checkTicket(tdeparture, tdestination);
		if (tickets != null && tickets.size() > 0) {
			setTicketlist(tickets);
			return "checkTicket";
		} else {
			setTicketlist(null);
			return "checkTicketError";
		}

	}

	// 管理员根据车票id查询车票信息
	public String adminFindByID() throws Exception {
		TTicket ticket = new TTicket();
		ticket = ticketService.adminFindByID(tid);
		if (ticket != null) {
			Map<String, Object> session = ActionContext.getContext().getSession();
			session.put("t_findID", ticket);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String sdftime = sdf.format(ticket.getTtime());
			// 将timestamp格式转换后，保存到session，赋值给jsp页面
			Map<String, Object> session1 = ActionContext.getContext().getSession();
			session1.put("sdftime", sdftime);
			return "adminFindByID";
		} else {
			return "error";
		}
	}

	// 管理员修改车票信息
	public String ticketUpdate() throws Exception {
		TTicket ticket = new TTicket();
		ttime = Timestamp.valueOf(time);
		ticket.setTid(tid);
		ticket.setTdeparture(tdeparture);
		ticket.setTdestination(tdestination);
		ticket.setTtime(ttime);
		ticket.setTprice(tprice);
		ticket.setTsaleCount(tsaleCount);
		if (ticketService.ticketUpdate(ticket)) {
			return "ticketUpdate";
		} else {
			return "ticketUpdateError";
		}

	}

	// 管理员删除车票
	public String deleteTicket() throws Exception {
		if (ticketService.deleteTicket(tid)) {
			return "deleteTicket";
		} else {
			return "deleteTicketError";
		}
	}

	public List<TTicket> getTicketlist() {
		return ticketlist;
	}

	public void setTicketlist(List<TTicket> ticketlist) {
		this.ticketlist = ticketlist;
	}

	public Integer getTid() {
		return tid;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public String getTdeparture() {
		return tdeparture;
	}

	public void setTdeparture(String tdeparture) {
		this.tdeparture = tdeparture;
	}

	public String getTdestination() {
		return tdestination;
	}

	public void setTdestination(String tdestination) {
		this.tdestination = tdestination;
	}

	public Float getTprice() {
		return tprice;
	}

	public void setTprice(Float tprice) {
		this.tprice = tprice;
	}

	public Timestamp getTtime() {
		return ttime;
	}

	public void setTtime(Timestamp ttime) {
		this.ttime = ttime;
	}

	public Integer getTsaleCount() {
		return tsaleCount;
	}

	public void setTsaleCount(Integer tsaleCount) {
		this.tsaleCount = tsaleCount;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public TTicket getModel() {
		return null;
	}

}
