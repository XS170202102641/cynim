package com.action;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.entity.TOrdersInfo;
import com.entity.TTicket;
import com.entity.TUser;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.service.OrdersService;

@SuppressWarnings("serial")
public class OrdersAction extends ActionSupport implements ModelDriven<TOrdersInfo> {
	@Resource(name = "ordersService")
	private OrdersService ordersService;
	private List<TOrdersInfo> torderslist = new ArrayList<TOrdersInfo>();
	Integer oid;
	TUser TUser;
	Integer tid;
	String tdeparture;
	String tdestination;
	Float tprice;
	Timestamp ttime;
	String pname;
	String pcardno;
	String ptelephone;
	String otype;

	// 查询订单信息
	public String queryOrders() throws Exception {
		// 获取user的session对象
		Map<String, Object> session2 = ActionContext.getContext().getSession();
		TUser = (TUser) session2.get("User");
		List<TOrdersInfo> orderslist = ordersService.queryOrders(TUser);
		if (orderslist != null && orderslist.size() > 0) {
			setTorderslist(orderslist);
			return "queryOrders";
		} else {
			return "queryOrdersError";
		}
	}

	// 添加订单信息
	public String add() throws Exception {
		TOrdersInfo ordersinfo = new TOrdersInfo();
		// 获取user的session对象
		Map<String, Object> session2 = ActionContext.getContext().getSession();
		TUser = (TUser) session2.get("User");
		// 获取ticket的session对象
		Map<String, Object> session3 = ActionContext.getContext().getSession();
		TTicket TTicket = (TTicket) session3.get("t_findID");
		// 获取ticket的session对象
		Map<String, Object> session4 = ActionContext.getContext().getSession();
		session4.put("ordersinfo", ordersinfo);
		ordersinfo.setOid(oid);
		ordersinfo.setTUser(TUser);
		ordersinfo.setTid(TTicket.getTid());
		ordersinfo.setTdeparture(TTicket.getTdeparture());
		ordersinfo.setTdestination(TTicket.getTdestination());
		ordersinfo.setTprice(TTicket.getTprice());
		ordersinfo.setTtime(TTicket.getTtime());
		ordersinfo.setPname(pname);
		ordersinfo.setPcardno(pcardno);
		ordersinfo.setPtelephone(ptelephone);
		ordersinfo.setOtype(otype);
		if (ordersService.add(ordersinfo)) {
			return "addOrders";
		} else {
			return "error";
		}
	}

	// 根据oid删除订单信息
	public String deleteOrders() throws Exception {
		if (ordersService.deleteOrders(oid,tid)) {
			return "deleteOrders";
		} else {
			return "error";
		}
	}

	// 取消订单时，根据oid删除订单信息
	public String cancleOrders() throws Exception {
		if (ordersService.deleteOrders(oid,tid)) {
			return "cancleOrders";
		} else {
			return "error";
		}
	}

	public OrdersService getOrdersService() {
		return ordersService;
	}

	public void setOrdersService(OrdersService ordersService) {
		this.ordersService = ordersService;
	}

	public List<TOrdersInfo> getTorderslist() {
		return torderslist;
	}

	public void setTorderslist(List<TOrdersInfo> torderslist) {
		this.torderslist = torderslist;
	}

	public Integer getOid() {
		return oid;
	}

	public void setOid(Integer oid) {
		this.oid = oid;
	}

	public TUser getTUser() {
		return TUser;
	}

	public void setTUser(TUser tUser) {
		TUser = tUser;
	}

	public Integer getTid() {
		return tid;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public String getTdeparture() {
		return tdeparture;
	}

	public void setTdeparture(String tdeparture) {
		this.tdeparture = tdeparture;
	}

	public String getTdestination() {
		return tdestination;
	}

	public void setTdestination(String tdestination) {
		this.tdestination = tdestination;
	}

	public Float getTprice() {
		return tprice;
	}

	public void setTprice(Float tprice) {
		this.tprice = tprice;
	}

	public Timestamp getTtime() {
		return ttime;
	}

	public void setTtime(Timestamp ttime) {
		this.ttime = ttime;
	}

	public String getOtype() {
		return otype;
	}

	public void setOtype(String otype) {
		this.otype = otype;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPcardno() {
		return pcardno;
	}

	public void setPcardno(String pcardno) {
		this.pcardno = pcardno;
	}

	public String getPtelephone() {
		return ptelephone;
	}

	public void setPtelephone(String ptelephone) {
		this.ptelephone = ptelephone;
	}

	public TOrdersInfo getModel() {
		return null;
	}

}
