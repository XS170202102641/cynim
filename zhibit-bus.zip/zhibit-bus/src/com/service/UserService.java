package com.service;

import com.entity.TUser;

public interface UserService {
	// 用户登录
	public TUser Login(Integer uid,String username, String password);

	// 用户注册
	public boolean Register(TUser user);
	
	//修改密码
	public boolean update(TUser user);
}
