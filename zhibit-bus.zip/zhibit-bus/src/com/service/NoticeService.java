package com.service;

import java.util.List;

import com.entity.TNotice;


public interface NoticeService {
		
		public List<TNotice> userqueryAll();
	
	
		public List<TNotice> queryAll();
		
		
		public boolean add(TNotice nti);
		
		
		public boolean shanchu(Integer nid);

		

}
