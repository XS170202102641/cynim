package com.service.impl;

import java.sql.Timestamp;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.dao.TicketDao;
import com.entity.TTicket;
import com.service.TicketService;

@Transactional(propagation = Propagation.REQUIRED)
public class TicketServiceImpl implements TicketService {
	@Resource(name = "ticketDao")
	TicketDao ticketDao;

	public List<TTicket> findTicket(String tdeparture, String tdestination, Timestamp ttime) {
		return ticketDao.findTicket(tdeparture, tdestination, ttime);
	}

	public TTicket findByID(Integer tid) {
		return ticketDao.findByID(tid);
	}

	public boolean addTicket(TTicket ticket) {
		return ticketDao.addTicket(ticket);
	}

	public List<TTicket> checkTicket(String tdeparture, String tdestination) {
		return ticketDao.checkTicket(tdeparture, tdestination);
	}

	public TTicket adminFindByID(Integer tid) {
		return ticketDao.adminFindByID(tid);
	}

	public boolean ticketUpdate(TTicket ticket) {
		return ticketDao.ticketUpdate(ticket);
	}

	public boolean deleteTicket(Integer tid) {
		return ticketDao.deleteTicket(tid);
	}
}
