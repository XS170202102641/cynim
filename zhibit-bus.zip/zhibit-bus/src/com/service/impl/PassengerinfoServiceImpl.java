package com.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.dao.PassengerinfoDao;
import com.entity.TPassengerinfo;
import com.entity.TUser;
import com.service.PassengerinfoService;

@Transactional(propagation = Propagation.REQUIRED)
public class PassengerinfoServiceImpl implements PassengerinfoService {

	@Resource(name="passengerinfoDao")
	PassengerinfoDao passengerinfoDao;
	//添加订票人信息
	public boolean add(TPassengerinfo passengerinfo){
		return passengerinfoDao.add(passengerinfo);
	}
	
	//根据用户ID查询订票人信息
	public List<TPassengerinfo> queryAll(TUser user){
		return passengerinfoDao.queryAll(user);
	}
	
	//删除订票人信息
	public boolean shanchu(Integer pid){
		return passengerinfoDao.shanchu(pid);
	}
	
	//修改订票人信息
	public boolean update(TPassengerinfo passengerinfo){
		return passengerinfoDao.update(passengerinfo);
	}
	
	// 根据Pid获取订票人信息
	public TPassengerinfo modify(Integer pid){
		return passengerinfoDao.modify(pid);
	}
	
	public List<TPassengerinfo> findByUid(TUser user) {
		return passengerinfoDao.findByUid(user);
	}

	public TPassengerinfo findByPid(Integer pid) {
		return passengerinfoDao.findByPid(pid);
	}
}
