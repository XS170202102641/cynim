package com.service.impl;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.service.AdministratorService;
import com.dao.AdministratorDao;
import com.entity.TAdministrator;


@Transactional(propagation = Propagation.REQUIRED)
public class AdministratorServiceImpl implements AdministratorService{
	@Resource(name="administratorDao")
	AdministratorDao administratorDao;
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	//管理员登录
	public TAdministrator Login(String aname, String apassword) {
		return administratorDao.Login(aname, apassword);
	}
	//管理员注册
	public boolean Register(TAdministrator admi) {
		return administratorDao.Register(admi);
	}
	//管理员信息修改
	public boolean update(TAdministrator admi) {
		return administratorDao.update(admi);
	}

}
