package com.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.dao.OrdersDao;
import com.entity.TOrdersInfo;
import com.entity.TUser;
import com.service.OrdersService;

@Transactional(propagation = Propagation.REQUIRED)
public class OrdersServiceImpl implements OrdersService {
	@Resource(name = "ordersDao")
	OrdersDao ordersDao;

	public boolean add(TOrdersInfo ordersinfo) {
		return ordersDao.add(ordersinfo);
	}

	public boolean deleteOrders(Integer oid,Integer tid) {
		return ordersDao.deleteOrders(oid,tid);
	}

	public List<TOrdersInfo> queryOrders(TUser tuser) {
		return ordersDao.queryOrders(tuser);
	}

}
