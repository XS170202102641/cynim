package com.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.dao.NoticeDao;
import com.entity.TNotice;
import com.service.NoticeService;


@Transactional(propagation = Propagation.REQUIRED)
public class NoticeServiceImpl implements NoticeService {
	@Resource(name="noticeDao")
	NoticeDao noticeDao;
	
	public List<TNotice> userqueryAll() {
		return noticeDao.userqueryAll();
	}
	
	public List<TNotice> queryAll() {
		return noticeDao.queryAll();
	}
	
	public boolean shanchu(Integer nid) {
		return noticeDao.shanchu(nid);
	}

	public boolean add(TNotice nti) {
		return noticeDao.add(nti);
	}

}
