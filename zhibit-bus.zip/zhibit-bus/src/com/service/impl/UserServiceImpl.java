package com.service.impl;

import com.dao.UserDao;
import com.entity.TUser;
import com.service.UserService;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


@Transactional(propagation = Propagation.REQUIRED)
public class UserServiceImpl implements UserService {
	@Resource(name="userDao")
	UserDao userDao;
	
	@Transactional(propagation = Propagation.NOT_SUPPORTED)
	public TUser Login(Integer uid,String username, String password) {
		return userDao.Login(uid,username,password);
	}

	public boolean Register(TUser user) {
		return userDao.Register(user);
	}
	
	//修改密码
	public boolean update(TUser user){
		return userDao.update(user);
	}
}
