package com.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.dao.MessageDao;
import com.entity.TMessage;
import com.service.MessageService;

@Transactional(propagation = Propagation.REQUIRED)
public class MessageServiceImpl implements MessageService {
	@Resource(name="messageDao")
	MessageDao messageDao;
	
	//用户添加留言
		public boolean addm(TMessage message){
			return messageDao.addm(message);
		}
	//管理员查看留言	
		public List<TMessage> queryAll() {
			return messageDao.queryAll();
		}
}
