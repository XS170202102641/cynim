package com.service;

import java.util.List;

import com.entity.TPassengerinfo;
import com.entity.TUser;

public interface PassengerinfoService {
	//添加订票人信息
	public boolean add(TPassengerinfo passengerinfo);
	
	//根据用户ID查询订票人信息
	public List<TPassengerinfo> queryAll(TUser user);
	
	//删除订票人信息
	public boolean shanchu(Integer pid);
	
	//修改订票人信息
	public boolean update(TPassengerinfo passengerinfo);
	
	// 根据Pid获取订票人信息
	public TPassengerinfo modify(Integer pid);
	
	// 根据uid查询订票人
	public List<TPassengerinfo> findByUid(TUser user);

	// 根据pid查询订票人
	public TPassengerinfo findByPid(Integer pid);
}


