package com.service;

import com.entity.TAdministrator;

public interface AdministratorService {
		// 管理员登录操作
		public TAdministrator Login(String aname, String apassword);

		// 管理员注册操作
		public boolean Register(TAdministrator admi);
		
		//管理员修改信息
		public boolean update(TAdministrator admi);

}
